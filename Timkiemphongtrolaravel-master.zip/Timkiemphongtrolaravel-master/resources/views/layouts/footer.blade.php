<footer class="pt-4 pb-4 custom-navbar" style="background-color: #333;">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mb-3">
                <h5 class="mb-3" style="color: #fff;">NHÀ TRỌ SINH VIÊN</h5>
                <p class="mb-1" style="color: #fff;"><strong>Điện thoại:</strong> 0335056988</p>
                <p class="mb-1" style="color: #fff;"><strong>Địa chỉ:</strong> 85 ngõ 70 Văn Trì, Minh Khai, Bắc Từ
                    Liêm, Hà Nội</p>
                <p class="mb-1" style="color: #fff;"><strong>Email:</strong> admin@gmail.com</p>
            </div>

            <div class="col-md-6 mb-3">
                <h5 class="mb-3"
                    style="background: linear-gradient(45deg, #EA4492, #004E9A);-webkit-background-clip: text;-webkit-text-fill-color: transparent;font-weight: 700;">
                    GIỚI THIỆU
                </h5>
                <p class="mb-3" style="color: #fff;">
                    Trang web <strong>Nhà Trọ Sinh Viên</strong> là nền tảng kết nối sinh viên với các nhà trọ uy tín,
                    cung cấp thông tin đầy đủ và nhanh chóng giúp bạn tìm kiếm nơi ở phù hợp với nhu cầu và ngân sách.
                </p>
                <h5 class="mb-3"
                    style="background: linear-gradient(45deg, #EA4492, #004E9A);-webkit-background-clip: text;-webkit-text-fill-color: transparent;font-weight: 700;">
                    THEO DÕI CHÚNG TÔI
                </h5>
                <ul class="list-inline">
                    <li class="list-inline-item">
                        <a href="https://www.facebook.com" target="_blank" class="text-white text-decoration-none">
                            <i class="fab fa-facebook fa-2x"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.youtube.com" target="_blank" class="text-white text-decoration-none">
                            <i class="fab fa-youtube fa-2x"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.twitter.com" target="_blank" class="text-white text-decoration-none">
                            <i class="fab fa-twitter fa-2x"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>
