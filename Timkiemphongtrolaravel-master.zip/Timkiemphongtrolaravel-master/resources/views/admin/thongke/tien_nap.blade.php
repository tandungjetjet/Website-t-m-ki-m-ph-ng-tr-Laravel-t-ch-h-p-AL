@extends('layouts.app')

@section('content')
    <div class="container" style="min-height: 100vh">
        <h1>Thống kê nạp tiền</h1>

        <form action="{{ route('thongke.napTien') }}" method="GET" class="row g-3 mb-4">
            <div class="col-auto">
                <label for="from_date" class="form-label">Từ ngày</label>
                <input type="date" name="from_date" id="from_date" class="form-control" value="{{ request('from_date') }}">
            </div>
            <div class="col-auto">
                <label for="to_date" class="form-label">Đến ngày</label>
                <input type="date" name="to_date" id="to_date" class="form-control" value="{{ request('to_date') }}">
            </div>
            <div class="col-auto align-self-end">
                <button type="submit" class="btn btn-primary">Lọc</button>
            </div>
        </form>

        @isset($tongTienNap)
            <div class="card my-3">
                <div class="card-body">
                    <h5>Tổng số giao dịch: {{ $tongGiaoDich }}</h5>
                    <h5>Tổng tiền nạp thành công: {{ number_format($tongTienNap) }} VNĐ</h5>
                </div>
            </div>

            <h4>Biểu đồ tổng tiền theo ngày</h4>
            <div style="max-width: 600px; height: 300px; margin: auto;">
                <canvas id="chartTongTien"></canvas>
            </div>

            <h4 class="mt-5">Thống kê theo ngày</h4>
            <table class="table table-bordered">
                <thead>
                    <tr style="background-color: black; color:white">
                        <th>Ngày</th>
                        <th>Số giao dịch</th>
                        <th>Tổng tiền (VNĐ)</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($thongKeTheoNgay as $item)
                        <tr>
                            <td>{{ $item->ngay }}</td>
                            <td>{{ $item->so_giao_dich }}</td>
                            <td>{{ number_format($item->tong_tien) }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

            <h4 class="mt-5">Thống kê theo user</h4>
            <table class="table table-bordered">
                <thead>
                    <tr style="background-color: black; color:white">
                        <th>Tên</th>
                        <th>Số lượng giao dịch</th>
                        <th>Tổng tiền (VNĐ)</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($thongKeTheoUser as $item)
                        <tr>
                            <td>{{ $item->name }}</td>
                            <td>{{ $item->sl }}</td>
                            <td>{{ number_format($item->total_amount) }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script>
                const labels = [
                    @foreach ($thongKeTheoNgay as $item)
                        '{{ $item->ngay }}',
                    @endforeach
                ];
                const dataTongTien = [
                    @foreach ($thongKeTheoNgay as $item)
                        {{ $item->tong_tien }},
                    @endforeach
                ];

                const ctx = document.getElementById('chartTongTien').getContext('2d');
                const chartTongTien = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Tổng tiền (VNĐ)',
                            data: dataTongTien,
                            backgroundColor: 'rgba(255, 182, 193, 0.5)',
                            borderColor: 'rgba(255, 105, 180, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return value.toLocaleString('en-US');
                                    }
                                }
                            }
                        },
                        responsive: true,
                        maintainAspectRatio: false
                    }
                });
            </script>
        @endisset

    </div>
@endsection
