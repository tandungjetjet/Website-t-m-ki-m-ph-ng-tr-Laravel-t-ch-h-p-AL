<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Xác nhận tài khoản</title>
</head>

<body style="font-family: Arial, sans-serif; background-color:#f8f9fa; margin:0; padding:20px;">
    <div
        style="max-width:600px; margin:0 auto; background:#ffffff; padding:20px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.1);">
        <h2 style="color:#007bff;">Xác nhận tài khoản</h2>
        <p>Chào bạn,</p>
        <p>Mã xác nhận của bạn là: <strong style="font-size:20px;">{{ $code }}</strong></p>
        <p>Vui lòng nhập mã này để hoàn tất quá trình đăng ký tài khoản.</p>
        <p>Nếu bạn không yêu cầu thao tác này, vui lòng bỏ qua email này.</p>
        <hr style="border:none; border-top:1px solid #eee;">
        <p style="font-size:12px; color:#777;">&copy; {{ date('Y') }} webNhaTro.</p>
    </div>
</body>

</html>
