@extends('layouts.app')

@section('content')
    <div class="container mt-5" style="min-height: 100vh">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">Xác thực tài khoản</div>
                    <div class="card-body">
                        @if (session('message'))
                            <div class="alert alert-info">{{ session('message') }}</div>
                        @endif
                        <form method="POST" action="{{ route('otp.verify.post') }}">
                            @csrf
                            <div class="mb-3">
                                <label for="otp" class="form-label">Nhập mã OTP</label>
                                <input type="text" name="otp" id="otp" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Xác thực</button>
                        </form>
                        @if ($errors->any())
                            <div class="mt-3">
                                @foreach ($errors->all() as $error)
                                    <div class="alert alert-danger">{{ $error }}</div>
                                @endforeach
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
