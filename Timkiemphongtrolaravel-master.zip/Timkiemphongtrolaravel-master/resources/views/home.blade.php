@extends('layouts.app')
@section('css')
    <link href="{{ url('public/frontend') }}/style.css" rel="stylesheet">
    <style>
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-box-orient: vertical;
            overflow: hidden;
            -webkit-line-clamp: 2;
        }
    </style>

    <style>
        /* Tiêu đề chính */
        .post-title {
            color: #a10115;
            border-bottom: 2px solid #c0b2b5;
            padding-bottom: 10px;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-title .icon {
            margin-right: 10px;
        }

        /* Tiêu đề phụ */
        .post-subtitle {
            color: #d72c15;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-subtitle .icon {
            margin-right: 10px;
        }

        /* Ngày đăng */
        .post-date {
            color: #a10115;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-date .icon {
            margin-right: 10px;
        }

        /* Tác giả */
        .post-author {
            color: #d72c15;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-author .icon {
            margin-right: 10px;
        }

        /* Bình luận */
        .post-comments {
            color: #a10115;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-comments .icon {
            margin-right: 10px;
        }

        /* Lượt xem */
        .post-views {
            color: #c0b2b5;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-views .icon {
            margin-right: 10px;
        }

        .vip-badge {
            position: absolute;
            top: 0;
            left: 0;
            transform: translate(20%, 150%);
            background-color: #ff0000;
            color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: bold;
            font-size: 1.2rem;
            text-shadow: 2px 2px 3px rgba(0, 0, 0, 0.9);
            animation: flash 1s linear infinite;
        }

        @keyframes flash {
            0% {
                background-color: #ff0000;
            }

            25% {
                background-color: #00ff00;
            }

            50% {
                background-color: #0000ff;
            }

            75% {
                background-color: #ffff00;
            }

            100% {
                background-color: #ff0000;
            }

        }
    </style>
@endsection
@section('content')
    @include('layouts.nav')
    @if (session('status'))
        <div class="alert alert-success" role="alert">
            {{ session('status') }}
        </div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif


    {{-- <h1 class="post-title"><span class="icon">📰</span> Bài Đăng Mới</h1>
    <h2 class="post-subtitle"><span class="icon">🔖</span> Tiêu Đề Bài Đăng</h2>
    <h3 class="post-date"><span class="icon">📅</span> Ngày Đăng: 18/02/2025</h3>
    <h4 class="post-author"><span class="icon">👤</span> Tác Giả: Admin</h4>
    <h5 class="post-comments"><span class="icon">💬</span> Bình Luận: 0</h5>
    <h6 class="post-views"><span class="icon">👁</span> Lượt Xem: 0</h6> --}}

    <div class="album py-5" style="min-height: 100vh">
        <style>
            .gradient-box {
                background: linear-gradient(45deg, red, white, pink);
            }
        </style>
        <div class="container">
            <div class="row">
                <div class="col-md-4 text-center">
                    <a href="{{ route('viewQuanHuyen', 8) }}">
                        <div class="border p-3 shadow"
                            style="background: linear-gradient(45deg, rgba(234,68,146,0.6), rgba(0,78,154,0.6)); border-radius: 20px;">
                            <img src="https://thethaovanhoa.mediacdn.vn/Upload/XmJnTp3BYsa9r8REW2g/files/2022/08/longbien/caulongbien13.jpg"
                                class="img-fluid" style="width:300px; height:200px; object-fit: cover; border-radius: 20px;"
                                alt="Long Biên">
                            <h5 class="mt-2">Long Biên</h5>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 text-center">
                    <a href="{{ route('viewQuanHuyen', 3) }}">
                        <div class="border p-3 shadow"
                            style="background: linear-gradient(45deg, rgba(234,68,146,0.6), rgba(0,78,154,0.6)); border-radius: 20px;">
                            <img src="https://timvanphong.com.vn/wp-content/uploads/2023/01/Toan-canh-toa-nha-Keangnam-Landmark-72-duong-Pham-Hung-Quan-Nam-Tu-Liem-Sunoffice.jpg"
                                class="img-fluid" style="width:300px; height:200px; object-fit: cover; border-radius: 20px;"
                                alt="Đống Đa">
                            <h5 class="mt-2">Cầu Giấy</h5>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 text-center">
                    <a href="{{ route('viewQuanHuyen', 11) }}">
                        <div class="border p-3 shadow"
                            style="background: linear-gradient(45deg, rgba(234,68,146,0.6), rgba(0,78,154,0.6)); border-radius: 20px;">
                            <img src="https://gonow.com.vn/wp-content/uploads/2024/05/du-lich-ha-noi-ve-dem-19.jpg"
                                class="img-fluid" style="width:300px; height:200px; object-fit: cover; border-radius: 20px;"
                                alt="Tây Hồ">
                            <h5 class="mt-2">Tây Hồ</h5>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <h5 class="post-title"><span class="icon">📰</span>Bài Đăng Mới</h5>
            <div class="row">
                <div class="col-md-8">
                    @isset($baivietvip)
                        @foreach ($baivietvip as $item)
                            <a class="text-reset text-decoration-none"
                                href="{{ route('xemchitiet', ['id' => $item->id, 'slug' => Str::slug($item->tieu_de)]) }}">
                                @php
                                    $imageNames = explode(',', $item->anh_gioi_thieu);
                                    $imageCount = count($imageNames);
                                @endphp

                                @if ($imageCount == 1)
                                    <div class="image-container" style="position: relative;">
                                        <img class="img-one" src="{{ asset('images') }}/{{ $imageNames[0] }}">
                                        <span class="price-tag"
                                            style="position: absolute; top: 10px; left: 10px; background: linear-gradient(45deg, #EA4492, #004E9A); color: #fff; padding: 5px 10px; border-radius: 5px; font-weight: bold; font-size: 1.1rem; text-shadow: 2px 2px 3px rgba(0,0,0,0.9);">
                                            {{ number_format($item->gia_tien, 0, ',', '.') }} VNĐ/tháng
                                        </span>
                                        <span class="vip-badge">
                                            HOT
                                        </span>
                                    </div>
                                @elseif ($imageCount == 2)
                                    <div class="image-container" style="position: relative;">
                                        <div class="row">
                                            <div class="col-6 padding_0px">
                                                <img class="img-two" src="{{ asset('images') }}/{{ $imageNames[0] }}">
                                            </div>
                                            <div class="col-6 padding_0px">
                                                <img class="img-two" src="{{ asset('images') }}/{{ $imageNames[1] }}">
                                            </div>
                                        </div>
                                        <span class="price-tag"
                                            style="position: absolute; top: 10px; left: 10px; background: linear-gradient(45deg, #EA4492, #004E9A); color: #fff; padding: 5px 10px; border-radius: 5px; font-weight: bold; font-size: 1.1rem; text-shadow: 2px 2px 3px rgba(0,0,0,0.9);">
                                            {{ number_format($item->gia_tien, 0, ',', '.') }} VNĐ/tháng
                                        </span>
                                        <span class="vip-badge">
                                            HOT
                                        </span>
                                    </div>
                                @elseif ($imageCount == 3)
                                    <div class="image-container" style="position: relative;">
                                        <div class="row">
                                            <div class="col-8 padding_0px">
                                                <img class="img-two" src="{{ asset('images') }}/{{ $imageNames[0] }}">
                                            </div>
                                            <div class="col-4 padding_0px">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <img class="img-three"
                                                            src="{{ asset('images') }}/{{ $imageNames[1] }}">
                                                    </div>
                                                    <div class="col-12">
                                                        <img class="img-three"
                                                            src="{{ asset('images') }}/{{ $imageNames[2] }}">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <span class="price-tag"
                                            style="position: absolute; top: 10px; left: 10px; background: linear-gradient(45deg, #EA4492, #004E9A); color: #fff; padding: 5px 10px; border-radius: 5px; font-weight: bold; font-size: 1.1rem; text-shadow: 2px 2px 3px rgba(0,0,0,0.9);">
                                            {{ number_format($item->gia_tien, 0, ',', '.') }} VNĐ/tháng
                                        </span>
                                        <span class="vip-badge">
                                            HOT
                                        </span>
                                    </div>
                                @endif

                                <div class="card mb-4 shadow-sm">
                                    <div class="card-body">
                                        <p class="card-text line-clamp-2">{{ $item->tieu_de }}</p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <span style="font-weight: bold">Đánh giá chủ nhà:</span>
                                                <span>
                                                    @if ($item->rate == 1)
                                                        <label style="color: rgb(255, 183, 0)">★☆☆☆☆</label>
                                                    @elseif ($item->rate == 2)
                                                        <label style="color: rgb(255, 183, 0)">★★☆☆☆</label>
                                                    @elseif ($item->rate == 3)
                                                        <label style="color: rgb(255, 183, 0)">★★★☆☆</label>
                                                    @elseif ($item->rate == 4)
                                                        <label style="color: rgb(255, 183, 0)">★★★★☆</label>
                                                    @elseif ($item->rate == 5)
                                                        <label style="color: rgb(255, 183, 0)">★★★★★</label>
                                                    @else
                                                        <label>Chưa có đánh giá</label>
                                                    @endif
                                                </span>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <span style="font-weight: bold">👤: {{ $item->hoTen }}</span>
                                                <span style="color: blue"> || </span>
                                                <span style="font-weight: bold">Số điện thoại: {{ $item->sdt }}</span>
                                            </div>
                                            <small class="text-muted">
                                                <span class="icon">📅</span> Ngày Đăng: {{ $item->updated_at }}
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        @endforeach
                    @endisset

                    <style>
                        .price-tag {
                            position: absolute;
                            top: 10px;
                            left: 10px;
                            background: linear-gradient(45deg, #EA4492, #004E9A);
                            color: #fff;
                            padding: 5px 10px;
                            border-radius: 5px;
                            font-weight: bold;
                            font-size: 1.1rem;
                            text-shadow: 2px 2px 3px rgba(0, 0, 0, 0.9);
                        }

                        .image-container {
                            position: relative;
                        }
                    </style>
                    @isset($baiviet)
                        @foreach ($baiviet as $item)
                            @if ($item->user_id == Auth::id())
                                <a href="{{ route('baiviet.dkVip', ['id' => $item->id]) }}" class="btn btn-danger">Đăng kí bài
                                    vip</a>
                            @endif

                            <a class="text-reset text-decoration-none"
                                href="{{ route('xemchitiet', ['id' => $item->id, 'slug' => Str::slug($item->tieu_de)]) }}">
                                @php
                                    $imageNames = explode(',', $item->anh_gioi_thieu);
                                    $imageCount = count($imageNames);
                                @endphp

                                @if ($imageCount == 1)
                                    <div class="image-container" style="position: relative;">
                                        <img class="img-one" src="{{ asset('images') }}/{{ $imageNames[0] }}">
                                        <span class="price-tag"
                                            style="
                                    position: absolute; 
                                    top: 10px; 
                                    left: 10px; 
                                    background: linear-gradient(45deg, #EA4492, #004E9A); 
                                    color: #fff; 
                                    padding: 5px 10px; 
                                    border-radius: 5px; 
                                    font-weight: bold;
                                    font-size: 1.1rem;
                                    text-shadow: 2px 2px 3px rgba(0,0,0,0.9);
                                ">
                                            {{ number_format($item->gia_tien, 0, ',', '.') }} VNĐ/tháng
                                        </span>
                                    </div>
                                @elseif ($imageCount == 2)
                                    <div class="image-container" style="position: relative;">
                                        <div class="row">
                                            <div class="col-6 padding_0px">
                                                <img class="img-two" src="{{ asset('images') }}/{{ $imageNames[0] }}">
                                            </div>
                                            <div class="col-6 padding_0px">
                                                <img class="img-two" src="{{ asset('images') }}/{{ $imageNames[1] }}">
                                            </div>
                                        </div>
                                        <span class="price-tag"
                                            style="
                                    position: absolute; 
                                    top: 10px; 
                                    left: 10px; 
                                    background: linear-gradient(45deg, #EA4492, #004E9A); 
                                    color: #fff; 
                                    padding: 5px 10px; 
                                    border-radius: 5px; 
                                    font-weight: bold;
                                    font-size: 1.1rem;
                                    text-shadow: 2px 2px 3px rgba(0,0,0,0.9);
                                ">
                                            {{ number_format($item->gia_tien, 0, ',', '.') }} VNĐ/tháng
                                        </span>
                                    </div>
                                @elseif ($imageCount == 3)
                                    <div class="image-container" style="position: relative;">
                                        <div class="row">
                                            <div class="col-8 padding_0px">
                                                <img class="img-two" src="{{ asset('images') }}/{{ $imageNames[0] }}">
                                            </div>
                                            <div class="col-4 padding_0px">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <img class="img-three"
                                                            src="{{ asset('images') }}/{{ $imageNames[1] }}">
                                                    </div>
                                                    <div class="col-12">
                                                        <img class="img-three"
                                                            src="{{ asset('images') }}/{{ $imageNames[2] }}">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <span class="price-tag"
                                            style="
                                    position: absolute; 
                                    top: 10px; 
                                    left: 10px; 
                                    background: linear-gradient(45deg, #EA4492, #004E9A); 
                                    color: #fff; 
                                    padding: 5px 10px; 
                                    border-radius: 5px; 
                                    font-weight: bold;
                                    font-size: 1.1rem;
                                    text-shadow: 2px 2px 3px rgba(0,0,0,0.9);
                                ">
                                            {{ number_format($item->gia_tien, 0, ',', '.') }} VNĐ/tháng
                                        </span>
                                    </div>
                                @endif

                                <div class="card mb-4 shadow-sm">
                                    <div class="card-body">
                                        <p class="card-text line-clamp-2">{{ $item->tieu_de }}</p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <span style="font-weight: bold">Đánh giá chủ nhà:</span>
                                                <span>
                                                    @if ($item->rate == 1)
                                                        <label style="color: rgb(255, 183, 0)">★☆☆☆☆</label>
                                                    @elseif ($item->rate == 2)
                                                        <label style="color: rgb(255, 183, 0)">★★☆☆☆</label>
                                                    @elseif ($item->rate == 3)
                                                        <label style="color: rgb(255, 183, 0)">★★★☆☆</label>
                                                    @elseif ($item->rate == 4)
                                                        <label style="color: rgb(255, 183, 0)">★★★★☆</label>
                                                    @elseif ($item->rate == 5)
                                                        <label style="color: rgb(255, 183, 0)">★★★★★</label>
                                                    @else
                                                        <label>Chưa có đánh giá</label>
                                                    @endif
                                                </span>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <span style="font-weight: bold">👤: {{ $item->hoTen }}</span>
                                                <span style="color: blue"> || </span>
                                                <span style="font-weight: bold">Số điện thoại: {{ $item->sdt }}</span>
                                            </div>
                                            <small class="text-muted">
                                                <span class="icon">📅</span> Ngày Đăng: {{ $item->updated_at }}
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        @endforeach
                    @endisset
                </div>
                <div class="col-md-4" style="border-radius:8px; border: 3px solid #868686; padding: 15px;">
                    <div class="row">
                        <div class="col-12">
                            <h5
                                style="
                                background: linear-gradient(45deg, #EA4492, #004E9A);
                                -webkit-background-clip: text;
                                -webkit-text-fill-color: transparent;
                                font-weight: 700;
                            ">
                                TOP CHỦ NHÀ ĐƯỢC ĐÁNH GIÁ CAO NHẤT
                            </h5>
                            @foreach ($partner as $item)
                                <div
                                    style="background: linear-gradient(45deg, rgba(234,68,146,0.2), rgba(0,78,154,0.2)); border-radius:8px; padding: 10px; margin-bottom: 10px;">
                                    <label>{{ $item->hoTen }}: </label>
                                    @if ($item->rate == 1)
                                        <label style="color: rgb(255, 183, 0)">★☆☆☆☆</label>
                                    @elseif($item->rate == 2)
                                        <label style="color: rgb(255, 183, 0)">★★☆☆☆</label>
                                    @elseif($item->rate == 3)
                                        <label style="color: rgb(255, 183, 0)">★★★☆☆</label>
                                    @elseif($item->rate == 4)
                                        <label style="color: rgb(255, 183, 0)">★★★★☆</label>
                                    @elseif($item->rate == 5)
                                        <label style="color: rgb(255, 183, 0)">★★★★★</label>
                                    @else
                                        <label style="font-weight:bold;">Chưa có đánh giá</label>
                                    @endif
                                </div>
                            @endforeach
                        </div>

                        <hr style="margin: 20px 0; border-top: 2px dashed #868686; width: 100%;">

                        <div class="col-12">
                            <h5
                                style="
                                background: linear-gradient(45deg, #EA4492, #004E9A);
                                -webkit-background-clip: text;
                                -webkit-text-fill-color: transparent;
                                font-weight: 700;
                            ">
                                BÀI VIẾT ĐỀ XUẤT
                            </h5>
                            @if ($recommendations->isEmpty())
                                <p style="color: #fff;">Không có bài viết đề xuất nào.</p>
                            @else
                                @foreach ($recommendations as $value)
                                    @php
                                        $imageNames = explode(',', $value->anh_gioi_thieu);
                                        $firstImage = count($imageNames) > 0 ? trim($imageNames[0]) : null;
                                    @endphp
                                    <a href="{{ route('xemchitiet', ['id' => $value->id, 'slug' => Str::slug($value->tieu_de)]) }}"
                                        class="d-flex align-items-center mb-3 text-decoration-none"
                                        style="background-color: #3a5560; border-radius: 8px; padding: 10px;">

                                        @if ($firstImage)
                                            <img src="{{ asset('images/' . $firstImage) }}" alt="Ảnh"
                                                style="width: 60px; height: 60px; object-fit: cover; border-radius: 6px; margin-right: 10px;">
                                        @endif

                                        <div>
                                            <div
                                                style="
                                                color: #fff; 
                                                font-weight: 600; 
                                                font-size: 14px; 
                                                white-space: nowrap; 
                                                overflow: hidden; 
                                                text-overflow: ellipsis; 
                                                max-width: 200px;">
                                                {{ $value->tieu_de }}
                                            </div>
                                            <div style="color: #fff; font-size: 13px;">
                                                {{ number_format($value->gia_tien, 0, ',', '.') }} VNĐ/tháng
                                            </div>
                                        </div>
                                    </a>
                                @endforeach
                            @endif
                        </div>
                    </div>
                </div>


            </div>

            <div class="pagi">
                {{ $baiviet->links() }}
            </div>
        </div>
    </div>

    @include('layouts.footer')
@endsection

@section('js')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function() {
            var selectedPhuongXaId = "{{ $phuong_xa_id ?? '' }}";
            var idQuanHuyen = $('#quan_huyen').val();
            $.ajax({
                url: '{{ route('baiviet.ajax_phuongxa') }}' + '/?idquanhuyen=' + idQuanHuyen,
                type: 'GET',
                success: function(data) {
                    console.log(data);
                    $('#phuong_xa').empty();
                    $('#phuong_xa').append(`<option value="0">---Chọn phường/xã---</option>`);
                    $.each(data, function(index, item) {
                        var option = $('<option>', {
                            value: item.id,
                            text: item.name
                        });
                        if (selectedPhuongXaId && selectedPhuongXaId == item.id) {
                            option.prop('selected', true);
                        }
                        $('#phuong_xa').append(option);
                    });
                }
            });

            $('#quan_huyen').on('change', function() {
                var idQuanHuyen = $(this).val();

                $.ajax({
                    url: '{{ route('baiviet.ajax_phuongxa') }}' + '/?idquanhuyen=' +
                        idQuanHuyen,
                    type: 'GET',
                    success: function(data) {
                        console.log(data);
                        $('#phuong_xa').empty();

                        $('#phuong_xa').append(
                            `<option value="0">---Chọn phường/xã---</option>`);
                        $.each(data, function(index, item) {
                            $('#phuong_xa').append($('<option>', {
                                value: item.id,
                                text: item.name
                            }));
                        });
                    }
                });
            });
        });
    </script>
@endsection
