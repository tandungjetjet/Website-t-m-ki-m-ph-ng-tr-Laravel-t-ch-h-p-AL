@extends('layouts.app')
@section('css')
    <link href="{{ url('public/frontend') }}/style.css" rel="stylesheet">
    <style>
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-box-orient: vertical;
            overflow: hidden;
            -webkit-line-clamp: 2;
        }
    </style>

    <style>
        /* Tiêu đề chính */
        .post-title {
            color: #a10115;
            border-bottom: 2px solid #c0b2b5;
            padding-bottom: 10px;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-title .icon {
            margin-right: 10px;
        }

        /* Tiêu đề phụ */
        .post-subtitle {
            color: #d72c15;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-subtitle .icon {
            margin-right: 10px;
        }

        /* Ngày đăng */
        .post-date {
            color: #a10115;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-date .icon {
            margin-right: 10px;
        }

        /* Tác giả */
        .post-author {
            color: #d72c15;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-author .icon {
            margin-right: 10px;
        }

        /* Bình luận */
        .post-comments {
            color: #a10115;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-comments .icon {
            margin-right: 10px;
        }

        /* Lượt xem */
        .post-views {
            color: #c0b2b5;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-views .icon {
            margin-right: 10px;
        }
    </style>
@endsection
@section('content')
    @include('layouts.nav')
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif



    <div class="album min-vh-100">
        <div class="container mt-5">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                    <li class="breadcrumb-item">{{ $quanHuyen[0]->name }}</li>
                </ol>
            </nav>
            <div class="row">
                <div class="col-md-8">
                    <style>
                        .price-tag {
                            position: absolute;
                            top: 10px;
                            left: 10px;
                            background: linear-gradient(45deg, #EA4492, #004E9A);
                            color: #fff;
                            padding: 5px 10px;
                            border-radius: 5px;
                            font-weight: bold;
                            font-size: 1.1rem;
                            text-shadow: 2px 2px 3px rgba(0, 0, 0, 0.9);
                        }

                        .image-container {
                            position: relative;
                        }
                    </style>
                    @isset($baiviet)
                        @foreach ($baiviet as $item)
                            @if ($item->user_id == Auth::id())
                                <a href="{{ route('baiviet.dkVip', ['id' => $item->id]) }}" class="btn btn-danger">Đăng kí bài
                                    vip</a>
                            @endif

                            <a class="text-reset text-decoration-none"
                                href="{{ route('xemchitiet', ['id' => $item->id, 'slug' => Str::slug($item->tieu_de)]) }}">
                                @php
                                    $imageNames = explode(',', $item->anh_gioi_thieu);
                                    $imageCount = count($imageNames);
                                @endphp

                                @if ($imageCount == 1)
                                    <div class="image-container" style="position: relative;">
                                        <img class="img-one" src="{{ asset('images') }}/{{ $imageNames[0] }}">
                                        <span class="price-tag"
                                            style="
                                    position: absolute; 
                                    top: 10px; 
                                    left: 10px; 
                                    background: linear-gradient(45deg, #EA4492, #004E9A); 
                                    color: #fff; 
                                    padding: 5px 10px; 
                                    border-radius: 5px; 
                                    font-weight: bold;
                                    font-size: 1.1rem;
                                    text-shadow: 2px 2px 3px rgba(0,0,0,0.9);
                                ">
                                            {{ number_format($item->gia_tien, 0, ',', '.') }} VNĐ
                                        </span>
                                    </div>
                                @elseif ($imageCount == 2)
                                    <div class="image-container" style="position: relative;">
                                        <div class="row">
                                            <div class="col-6 padding_0px">
                                                <img class="img-two" src="{{ asset('images') }}/{{ $imageNames[0] }}">
                                            </div>
                                            <div class="col-6 padding_0px">
                                                <img class="img-two" src="{{ asset('images') }}/{{ $imageNames[1] }}">
                                            </div>
                                        </div>
                                        <span class="price-tag"
                                            style="
                                    position: absolute; 
                                    top: 10px; 
                                    left: 10px; 
                                    background: linear-gradient(45deg, #EA4492, #004E9A); 
                                    color: #fff; 
                                    padding: 5px 10px; 
                                    border-radius: 5px; 
                                    font-weight: bold;
                                    font-size: 1.1rem;
                                    text-shadow: 2px 2px 3px rgba(0,0,0,0.9);
                                ">
                                            {{ number_format($item->gia_tien, 0, ',', '.') }} VNĐ
                                        </span>
                                    </div>
                                @elseif ($imageCount == 3)
                                    <div class="image-container" style="position: relative;">
                                        <div class="row">
                                            <div class="col-8 padding_0px">
                                                <img class="img-two" src="{{ asset('images') }}/{{ $imageNames[0] }}">
                                            </div>
                                            <div class="col-4 padding_0px">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <img class="img-three"
                                                            src="{{ asset('images') }}/{{ $imageNames[1] }}">
                                                    </div>
                                                    <div class="col-12">
                                                        <img class="img-three"
                                                            src="{{ asset('images') }}/{{ $imageNames[2] }}">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <span class="price-tag"
                                            style="
                                    position: absolute; 
                                    top: 10px; 
                                    left: 10px; 
                                    background: linear-gradient(45deg, #EA4492, #004E9A); 
                                    color: #fff; 
                                    padding: 5px 10px; 
                                    border-radius: 5px; 
                                    font-weight: bold;
                                    font-size: 1.1rem;
                                    text-shadow: 2px 2px 3px rgba(0,0,0,0.9);
                                ">
                                            {{ number_format($item->gia_tien, 0, ',', '.') }} VNĐ
                                        </span>
                                    </div>
                                @endif

                                <div class="card mb-4 shadow-sm">
                                    <div class="card-body">
                                        <p class="card-text line-clamp-2">{{ $item->tieu_de }}</p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <span style="font-weight: bold">Đánh giá chủ nhà:</span>
                                                <span>
                                                    @if ($item->rate == 1)
                                                        <label style="color: rgb(255, 183, 0)">★☆☆☆☆</label>
                                                    @elseif ($item->rate == 2)
                                                        <label style="color: rgb(255, 183, 0)">★★☆☆☆</label>
                                                    @elseif ($item->rate == 3)
                                                        <label style="color: rgb(255, 183, 0)">★★★☆☆</label>
                                                    @elseif ($item->rate == 4)
                                                        <label style="color: rgb(255, 183, 0)">★★★★☆</label>
                                                    @elseif ($item->rate == 5)
                                                        <label style="color: rgb(255, 183, 0)">★★★★★</label>
                                                    @else
                                                        <label>Chưa có đánh giá</label>
                                                    @endif
                                                </span>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <span style="font-weight: bold">👤: {{ $item->hoTen }}</span>
                                                <span style="color: blue"> || </span>
                                                <span style="font-weight: bold">Số điện thoại: {{ $item->sdt }}</span>
                                            </div>
                                            <small class="text-muted">
                                                <span class="icon">📅</span> Ngày Đăng: {{ $item->updated_at }}
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        @endforeach
                    @endisset
                </div>
                <div class="col-md-4" style="border-radius:8px; border: 3px solid #868686; padding: 15px;">
                    <h5>TOP CHỦ NHÀ ĐƯỢC ĐÁNH GIÁ CAO NHẤT</h5>
                    @foreach ($partner as $item)
                        <div
                            style="background: linear-gradient(45deg, rgba(234,68,146,0.2), rgba(0,78,154,0.2)); border-radius:8px; padding: 10px; margin-bottom: 10px;">
                            <label>{{ $item->hoTen }}: </label>
                            @if ($item->rate == 1)
                                <label style="color: rgb(255, 183, 0)">★☆☆☆☆</label>
                            @elseif($item->rate == 2)
                                <label style="color: rgb(255, 183, 0)">★★☆☆☆</label>
                            @elseif($item->rate == 3)
                                <label style="color: rgb(255, 183, 0)">★★★☆☆</label>
                            @elseif($item->rate == 4)
                                <label style="color: rgb(255, 183, 0)">★★★★☆</label>
                            @elseif($item->rate == 5)
                                <label style="color: rgb(255, 183, 0)">★★★★★</label>
                            @else
                                <label style="font-weight:bold;">Chưa có đánh giá</label>
                            @endif
                        </div>
                    @endforeach
                </div>

            </div>

            <div class="pagi">
                {{ $baiviet->links() }}
            </div>
        </div>
    </div>

    @include('layouts.footer')
@endsection
