

<?php $__env->startSection('content'); ?>
    <div class="container mt-5" style="min-height: 100vh">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">Xác thực tài khoản</div>
                    <div class="card-body">
                        <?php if(session('message')): ?>
                            <div class="alert alert-info"><?php echo e(session('message')); ?></div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('otp.verify.post')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="otp" class="form-label">Nhập mã OTP</label>
                                <input type="text" name="otp" id="otp" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Xác thực</button>
                        </form>
                        <?php if($errors->any()): ?>
                            <div class="mt-3">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nhatro\nhatro\resources\views/auth/otp.blade.php ENDPATH**/ ?>