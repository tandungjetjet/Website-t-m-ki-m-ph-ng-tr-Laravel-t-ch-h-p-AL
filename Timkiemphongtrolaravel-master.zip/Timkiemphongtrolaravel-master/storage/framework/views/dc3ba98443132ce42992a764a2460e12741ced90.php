<nav class="navbar navbar-expand-lg navbar-dark custom-navbar">
    <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03"
            aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-center" id="navbarTogglerDemo03">
            <form action="" method="get" class="form-search">
                <ul class="navbar-nav mr-auto align-items-center">
                    <li class="nav-item dropdown mr-2">
                        <select class="form-control" name="type">
                            <option value="" <?php if (isset($_GET['type']) && $_GET['type'] == '') {
                                echo 'selected';
                            } ?>>
                                Loại nhà
                            </option>
                            <option value="0" <?php if (isset($_GET['type']) && $_GET['type'] == 0) {
                                echo 'selected';
                            } ?>>
                                Nhà trọ
                            </option>
                            <option value="1" <?php if (isset($_GET['type']) && $_GET['type'] == 1) {
                                echo 'selected';
                            } ?>>
                                CCMN
                            </option>
                            <option value="2" <?php if (isset($_GET['type']) && $_GET['type'] == 2) {
                                echo 'selected';
                            } ?>>
                                Nguyên căn
                            </option>
                        </select>
                    </li>
                    <li class="nav-item dropdown mr-2">
                        <select class="form-control" name="dien_tich">
                            <option value="">
                                Diện tích
                            </option>
                            <option value="under20" <?php if (isset($_GET['dien_tich']) && $_GET['dien_tich'] == 'under20') {
                                echo 'selected';
                            } ?>>
                                Dưới 20m²
                            </option>
                            <option value="20-50" <?php if (isset($_GET['dien_tich']) && $_GET['dien_tich'] == '20-50') {
                                echo 'selected';
                            } ?>>
                                20m² - 50m²
                            </option>
                            <option value="50-100" <?php if (isset($_GET['dien_tich']) && $_GET['dien_tich'] == '50-100') {
                                echo 'selected';
                            } ?>>
                                50m² - 100m²
                            </option>
                            <option value="over100" <?php if (isset($_GET['dien_tich']) && $_GET['dien_tich'] == 'over100') {
                                echo 'selected';
                            } ?>>
                                Trên 100m²
                            </option>
                        </select>
                    </li>
                    <li class="nav-item dropdown mr-2">
                        <select class="form-control" name="gia_tien">
                            <option value="">
                                Giá tiền
                            </option>
                            <option value="under3000" <?php if (isset($_GET['gia_tien']) && $_GET['gia_tien'] == 'under3000') {
                                echo 'selected';
                            } ?>>
                                Dưới 3.000.000
                            </option>
                            <option value="3000-5000" <?php if (isset($_GET['gia_tien']) && $_GET['gia_tien'] == '3000-5000') {
                                echo 'selected';
                            } ?>>
                                3.000.000 - 5.000.000
                            </option>
                            <option value="over5000" <?php if (isset($_GET['gia_tien']) && $_GET['gia_tien'] == 'over5000') {
                                echo 'selected';
                            } ?>>
                                Trên 5.000.000
                            </option>
                        </select>
                    </li>
                    <li class="nav-item">
                        <button class="btn btn-search">Tìm kiếm</button>
                    </li>
                </ul>
            </form>
        </div>
    </div>
</nav>

<!-- CSS tùy chỉnh -->
<style>
    .custom-navbar {
        /* Nền gradient với màu #EA4492 và #004E9A */
        background: linear-gradient(45deg, #EA4492, #004E9A);
        padding: 10px 0;
        border-radius: 8px;
        /* Bo tròn góc navbar */
    }

    /* Tùy chỉnh nút toggle */
    .custom-navbar .navbar-toggler {
        border-color: rgba(240, 239, 234, 0.7);
    }

    .custom-navbar .navbar-toggler-icon {
        background-image: url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='%23f0efea' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E");
    }

    /* Style cho các ô select */
    .custom-navbar .form-control {
        background-color: #f0efea;
        color: #a10115;
        border: none;
        border-radius: 6px;
        /* Bo tròn ô select */
        padding: 5px 10px;
    }

    .custom-navbar .form-control:focus {
        outline: none;
        box-shadow: 0 0 0 2px #c0b2b5;
    }

    /* Style cho nút tìm kiếm */
    .custom-navbar .btn-search {
        background-color: #f0efea;
        color: #a10115;
        border: 2px solid #c0b2b5;
        padding: 8px 20px;
        margin-left: 10px;
        border-radius: 6px;
        /* Bo tròn nút */
        transition: background-color 0.3s, color 0.3s;
    }

    .custom-navbar .btn-search:hover {
        background-color: #c0b2b5;
        color: #f0efea;
    }
</style>

<!-- jQuery và script Ajax (giữ nguyên chức năng cho dropdown Tỉnh/Thành phố, Quận/Huyện, Phường/Xã) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $("#tinh_thanhpho").on("change", function() {
            var idTinhThanhPho = $(this).val();
            $.ajax({
                url: '<?php echo e(route('baiviet.ajax_quanhuyen')); ?>' +
                    "/?idtinhthanhpho=" +
                    idTinhThanhPho,
                type: "GET",
                success: function(data) {
                    console.log(data);
                    $("#quan_huyen").empty();
                    $.each(data, function(index, item) {
                        $("#quan_huyen").append(
                            $("<option>", {
                                value: item.id,
                                text: item.name,
                            })
                        );
                    });
                },
            });
        });
        $("#quan_huyen").on("change", function() {
            var idQuanHuyen = $(this).val();
            $.ajax({
                url: '<?php echo e(route('baiviet.ajax_phuongxa')); ?>' +
                    "/?idquanhuyen=" +
                    idQuanHuyen,
                type: "GET",
                success: function(data) {
                    console.log(data);
                    $("#phuong_xa").empty();
                    $.each(data, function(index, item) {
                        $("#phuong_xa").append(
                            $("<option>", {
                                value: item.id,
                                text: item.name,
                            })
                        );
                    });
                },
            });
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\nhatro\nhatro\resources\views/layouts/nav.blade.php ENDPATH**/ ?>