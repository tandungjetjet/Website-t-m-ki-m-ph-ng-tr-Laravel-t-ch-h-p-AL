
<?php $__env->startSection('css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="<?php echo e(url('public/frontend')); ?>/style.css" rel="stylesheet">

    <style>
        .rating {
            display: flex;
            flex-direction: row-reverse;
            justify-content: flex-end;
        }

        .rating>input {
            display: none;
        }

        .rating>label {
            font-size: 1.5vw;
            cursor: pointer;
            /* Màu mặc định khi không hover/không được chọn */
            color: #ccc;
            transition: all 0.2s ease-in-out;
        }

        /* Khi hover, hoặc khi đã chọn (input checked) */
        .rating>input:checked~label,
        .rating>label:hover,
        .rating>label:hover~label {
            background: linear-gradient(45deg, #EA4492, #004E9A);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <hr>

    <div class="container">
        <!-- Thông tin căn hộ/chủ nhà -->
        <div class="card mb-3 shadow-sm"
            style="border-radius: 8px; background: linear-gradient(45deg, rgba(234,68,146,0.1), rgba(0,78,154,0.1));">
            <div class="card-body">
                <h3 class="mb-3">
                    Giá tiền: <span
                        class="text-primary font-weight-bold"><?php echo e(number_format($baiviet[0]->gia_tien, 0, ',', '.')); ?>

                        VNĐ/tháng</span>
                    || Diện tích: <span class="text-success font-weight-bold"><?php echo e($baiviet[0]->dien_tich); ?></span> mét vuông
                    || Loại: <span class="text-info font-weight-bold">
                        <?php if($baiviet[0]->type == 0): ?>
                            Nhà trọ
                        <?php elseif($baiviet[0]->type == 1): ?>
                            Chung cư mini
                        <?php elseif($baiviet[0]->type == 2): ?>
                            Nhà riêng
                        <?php endif; ?>
                    </span>
                </h3>
                <h3 class="mb-0">
                    Địa chỉ: <span class="text-secondary"><?php echo e($baiviet[0]->phuongxa); ?>, <?php echo e($baiviet[0]->quanhuyen); ?>, <?php echo e($baiviet[0]->tinhtp); ?>

                        </span>
                </h3>
            </div>
        </div>

        <div class="container mt-4">
            <div class="row">
                <!-- Phần Carousel ảnh giới thiệu -->
                <div class="col-md-8">
                    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <?php
                                $imageNames = explode(',', $baiviet[0]->anh_gioi_thieu);
                            ?>
                            <?php $__currentLoopData = $imageNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                                    <img src="<?php echo e(asset('images/' . $item)); ?>" class="d-block w-100 img-one"
                                        style="max-height: 400px;" alt="...">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-target="#carouselExampleControls"
                            data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-target="#carouselExampleControls"
                            data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </button>
                    </div>
                </div>

                <!-- Thông tin chủ nhà, đánh giá và nút liên hệ -->
                <div class="col-md-4">
                    <div class="card border border-primary rounded-lg shadow-lg"
                        style="background: linear-gradient(45deg, rgba(234,68,146,0.2), rgba(0,78,154,0.2));">
                        <div class="card-body text-center">
                            <img src="https://cdn.eva.vn/upload/4-2023/images/2023-10-09/picture-56-1696846109-744-width1430height953.jpg"
                                class="rounded-circle mb-3 border border-primary p-1"
                                style="width: 80px; height: 80px; object-fit: cover;">
                            <h5 class="font-weight-bold"><?php echo e($baiviet[0]->hoTen); ?></h5>
                            <div class="rating d-flex justify-content-center">
                                <input type="radio" name="rating" value="5"
                                    <?php echo e($baiviet[0]->rate == 5 ? 'checked' : ''); ?>>
                                <label for="star5">☆</label>
                                <input type="radio" name="rating" value="4"
                                    <?php echo e($baiviet[0]->rate == 4 ? 'checked' : ''); ?>>
                                <label for="star4">☆</label>
                                <input type="radio" name="rating" value="3"
                                    <?php echo e($baiviet[0]->rate == 3 ? 'checked' : ''); ?>>
                                <label for="star3">☆</label>
                                <input type="radio" name="rating" value="2"
                                    <?php echo e($baiviet[0]->rate == 2 ? 'checked' : ''); ?>>
                                <label for="star2">☆</label>
                                <input type="radio" name="rating" value="1"
                                    <?php echo e($baiviet[0]->rate == 1 ? 'checked' : ''); ?>>
                                <label for="star1">☆</label>
                            </div>
                            <p class="text-muted mb-2">Tham gia: <strong>5 năm</strong></p>

                            <a href="https://zalo.me/<?php echo e($baiviet[0]->sdt); ?>" target="_blank"
                                class="btn btn-primary btn-block mt-2"
                                style="background: linear-gradient(45deg, #EA4492, #004E9A); border: none; color: #fff;">
                                <img src="https://banner2.cleanpng.com/20180907/bub/kisspng-logo-scalable-vector-graphics-clip-art-zalo-zalo-logo-svg-vector-amp-png-transparent-vecto-1713943674787.webp"
                                    style="width: 35px; margin-right: 5px; border-radius: 50%;"> Chat qua Zalo
                            </a>

                            <!-- Button ẩn số, khi bấm sẽ hiển thị số điện thoại đầy đủ -->
                            <button id="revealNumberButton" class="btn btn-success btn-block mt-2"
                                style="background: linear-gradient(45deg, #EA4492, #004E9A); border: none; color: #fff;"
                                data-number="<?php echo e($baiviet[0]->sdt); ?>">
                                📞 Hiện số
                            </button>
                        </div>
                    </div>
                </div>

                <script>
                    document.getElementById('revealNumberButton').addEventListener('click', function() {
                        var number = this.getAttribute('data-number');
                        this.innerHTML = "📞 " + number;
                    });
                </script>
            </div>
        </div>

        <br>

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-reset text-decoration-none">Trang
                        chủ</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($baiviet[0]->tieu_de); ?></li>
            </ol>
        </nav>

        <hr>
        <h6>Đánh giá chủ nhà</h6>
        <div class="rating">
            <input type="radio" name="rating" value="5" id="star5"
                <?php echo e($baiviet[0]->rate == 5 ? 'checked' : ''); ?>>
            <label for="star5">☆</label>
            <input type="radio" name="rating" value="4" id="star4"
                <?php echo e($baiviet[0]->rate == 4 ? 'checked' : ''); ?>>
            <label for="star4">☆</label>
            <input type="radio" name="rating" value="3" id="star3"
                <?php echo e($baiviet[0]->rate == 3 ? 'checked' : ''); ?>>
            <label for="star3">☆</label>
            <input type="radio" name="rating" value="2" id="star2"
                <?php echo e($baiviet[0]->rate == 2 ? 'checked' : ''); ?>>
            <label for="star2">☆</label>
            <input type="radio" name="rating" value="1" id="star1"
                <?php echo e($baiviet[0]->rate == 1 ? 'checked' : ''); ?>>
            <label for="star1">☆</label>
        </div>
        <hr>

        <h5><?php echo e($baiviet[0]->tieu_de); ?></h5>
        <div class="row">
            <div style="max-height: 100vh; overflow-y: auto;" class="col-8">
                <?php echo $baiviet[0]->noi_dung; ?>

            </div>
            <div class="col-4" style="max-height: 100vh; overflow-y: auto;">
                <h4>Bài viết cùng người đăng</h4>
                <?php if(count($sameBaiViet) > 0): ?>
                    <div class="list-group">
                        <?php $__currentLoopData = $sameBaiViet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $imageNames = explode(',', $value->anh_gioi_thieu);
                                $firstImage = count($imageNames) > 0 ? trim($imageNames[0]) : null;
                            ?>
                            <a href="<?php echo e(route('xemchitiet', ['id' => $value->id, 'slug' => Str::slug($value->tieu_de)])); ?>"
                                class="list-group-item list-group-item-action mb-3"
                                style="border-radius: 10px; background: linear-gradient(45deg, rgba(234,68,146,0.2), rgba(0,78,154,0.2));">
                                <?php if($firstImage): ?>
                                    <img src="<?php echo e(asset('images/' . $firstImage)); ?>" class="d-block w-100 rounded"
                                        style="max-height: 200px; object-fit: cover;" alt="Ảnh bài viết">
                                <?php endif; ?>
                                <div class="mt-2">
                                    <h5 class="mb-1">
                                        Địa chỉ: <span class="text-secondary"><?php echo e($value->tinhtp); ?>,
                                            <?php echo e($value->quanhuyen); ?>, <?php echo e($value->phuongxa); ?></span>
                                    </h5>
                                    <p class="mb-0">
                                        Giá tiền: <span
                                            class="text-primary font-weight-bold"><?php echo e(number_format($value->gia_tien, 0, ',', '.')); ?>

                                            VNĐ/tháng</span>
                                    </p>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p>Không có nhà thuê nào khác của người dùng này.</p>
                <?php endif; ?>
            </div>

        </div>

    </div>

    <hr>
    <div class="container">
        <h4>Bình luận</h4>
        <?php if(Auth::check()): ?>
            
            <form action="<?php echo e(route('comment.store', $baiviet[0]->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="">Nội dung bình luận</label>
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" class="form-control">
                    <textarea name="noi_dung" class="form-control" placeholder="Nhập nội dung (*)" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Đăng bình luận</button>
            </form>
        <?php else: ?>
            <span style="color: #EA4492">Vui lòng đăng nhập để sử dụng tính năng này</span>
        <?php endif; ?>
        <br>
        <div id="comment">
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="media">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/User-avatar.svg/2048px-User-avatar.svg.png"
                        class="mr-3" width="40">
                    <div class="media-body">
                        <h5 class="mt-0"><?php echo e($item->name); ?></h5>
                        <p><?php echo e($item->noi_dung); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function() {
            // Gắn sự kiện click vào các label của div .rating để gửi đánh giá
            $(".rating label").on("click", function() {
                var rating = $(this).prev().val();
                var user_id_2 = <?php echo e($baiviet[0]->user_id); ?>;
                var isLoggedIn = <?php echo e(auth()->check() ? 'true' : 'false'); ?>;
                if (isLoggedIn) {
                    if (typeof rating !== 'undefined') {
                        submitRating(rating, user_id_2);
                    } else {
                        console.log('Rating không tồn tại');
                    }
                } else {
                    alert("Bạn cần đăng nhập khi sử dụng chức năng này!");
                    location.reload();
                }
            });
        });

        function submitRating(rating, user_id_2) {
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('partner.rate')); ?>",
                data: JSON.stringify({
                    rating: rating,
                    user_id_2: user_id_2
                }),
                contentType: "application/json",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    console.log(response);
                    alert("Đánh giá đã được gửi thành công!");
                    location.reload();
                },
                error: function(xhr, status, error) {
                    alert("Đã xảy ra lỗi khi gửi đánh giá!");
                    location.reload();
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nhatro\resources\views/client/baiviet_detail.blade.php ENDPATH**/ ?>