
<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(url('public/frontend')); ?>/style.css" rel="stylesheet">
    <style>
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-box-orient: vertical;
            overflow: hidden;
            -webkit-line-clamp: 2;
        }
    </style>

    <style>
        /* Tiêu đề chính */
        .post-title {
            color: #a10115;
            border-bottom: 2px solid #c0b2b5;
            padding-bottom: 10px;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-title .icon {
            margin-right: 10px;
        }

        /* Tiêu đề phụ */
        .post-subtitle {
            color: #d72c15;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-subtitle .icon {
            margin-right: 10px;
        }

        /* Ngày đăng */
        .post-date {
            color: #a10115;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-date .icon {
            margin-right: 10px;
        }

        /* Tác giả */
        .post-author {
            color: #d72c15;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-author .icon {
            margin-right: 10px;
        }

        /* Bình luận */
        .post-comments {
            color: #a10115;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-comments .icon {
            margin-right: 10px;
        }

        /* Lượt xem */
        .post-views {
            color: #c0b2b5;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }

        .post-views .icon {
            margin-right: 10px;
        }

        .vip-badge {
            position: absolute;
            top: 0;
            left: 0;
            transform: translate(20%, 150%);
            background-color: #ff0000;
            color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: bold;
            font-size: 1.2rem;
            text-shadow: 2px 2px 3px rgba(0, 0, 0, 0.9);
            animation: flash 1s linear infinite;
        }

        @keyframes  flash {
            0% {
                background-color: #ff0000;
            }

            25% {
                background-color: #00ff00;
            }

            50% {
                background-color: #0000ff;
            }

            75% {
                background-color: #ffff00;
            }

            100% {
                background-color: #ff0000;
            }

        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    

    <div class="album py-5" style="min-height: 100vh">
        <style>
            .gradient-box {
                background: linear-gradient(45deg, red, white, pink);
            }
        </style>
        <div class="container">
            <div class="row">
                <div class="col-md-4 text-center">
                    <a href="<?php echo e(route('viewQuanHuyen', 8)); ?>">
                        <div class="border p-3 shadow"
                            style="background: linear-gradient(45deg, rgba(234,68,146,0.6), rgba(0,78,154,0.6)); border-radius: 20px;">
                            <img src="https://thethaovanhoa.mediacdn.vn/Upload/XmJnTp3BYsa9r8REW2g/files/2022/08/longbien/caulongbien13.jpg"
                                class="img-fluid" style="width:300px; height:200px; object-fit: cover; border-radius: 20px;"
                                alt="Long Biên">
                            <h5 class="mt-2">Long Biên</h5>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 text-center">
                    <a href="<?php echo e(route('viewQuanHuyen', 3)); ?>">
                        <div class="border p-3 shadow"
                            style="background: linear-gradient(45deg, rgba(234,68,146,0.6), rgba(0,78,154,0.6)); border-radius: 20px;">
                            <img src="https://timvanphong.com.vn/wp-content/uploads/2023/01/Toan-canh-toa-nha-Keangnam-Landmark-72-duong-Pham-Hung-Quan-Nam-Tu-Liem-Sunoffice.jpg"
                                class="img-fluid" style="width:300px; height:200px; object-fit: cover; border-radius: 20px;"
                                alt="Đống Đa">
                            <h5 class="mt-2">Cầu Giấy</h5>
                        </div>
                    </a>
                </div>
                <div class="col-md-4 text-center">
                    <a href="<?php echo e(route('viewQuanHuyen', 11)); ?>">
                        <div class="border p-3 shadow"
                            style="background: linear-gradient(45deg, rgba(234,68,146,0.6), rgba(0,78,154,0.6)); border-radius: 20px;">
                            <img src="https://gonow.com.vn/wp-content/uploads/2024/05/du-lich-ha-noi-ve-dem-19.jpg"
                                class="img-fluid" style="width:300px; height:200px; object-fit: cover; border-radius: 20px;"
                                alt="Tây Hồ">
                            <h5 class="mt-2">Tây Hồ</h5>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <h5 class="post-title"><span class="icon">📰</span>Bài Đăng Mới</h5>
            <div class="row">
                <div class="col-md-8">
                    <?php if(isset($baivietvip)): ?>
                        <?php $__currentLoopData = $baivietvip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="text-reset text-decoration-none"
                                href="<?php echo e(route('xemchitiet', ['id' => $item->id, 'slug' => Str::slug($item->tieu_de)])); ?>">
                                <?php
                                    $imageNames = explode(',', $item->anh_gioi_thieu);
                                    $imageCount = count($imageNames);
                                ?>

                                <?php if($imageCount == 1): ?>
                                    <div class="image-container" style="position: relative;">
                                        <img class="img-one" src="<?php echo e(asset('images')); ?>/<?php echo e($imageNames[0]); ?>">
                                        <span class="price-tag"
                                            style="position: absolute; top: 10px; left: 10px; background: linear-gradient(45deg, #EA4492, #004E9A); color: #fff; padding: 5px 10px; border-radius: 5px; font-weight: bold; font-size: 1.1rem; text-shadow: 2px 2px 3px rgba(0,0,0,0.9);">
                                            <?php echo e(number_format($item->gia_tien, 0, ',', '.')); ?> VNĐ/tháng
                                        </span>
                                        <span class="vip-badge">
                                            HOT
                                        </span>
                                    </div>
                                <?php elseif($imageCount == 2): ?>
                                    <div class="image-container" style="position: relative;">
                                        <div class="row">
                                            <div class="col-6 padding_0px">
                                                <img class="img-two" src="<?php echo e(asset('images')); ?>/<?php echo e($imageNames[0]); ?>">
                                            </div>
                                            <div class="col-6 padding_0px">
                                                <img class="img-two" src="<?php echo e(asset('images')); ?>/<?php echo e($imageNames[1]); ?>">
                                            </div>
                                        </div>
                                        <span class="price-tag"
                                            style="position: absolute; top: 10px; left: 10px; background: linear-gradient(45deg, #EA4492, #004E9A); color: #fff; padding: 5px 10px; border-radius: 5px; font-weight: bold; font-size: 1.1rem; text-shadow: 2px 2px 3px rgba(0,0,0,0.9);">
                                            <?php echo e(number_format($item->gia_tien, 0, ',', '.')); ?> VNĐ/tháng
                                        </span>
                                        <span class="vip-badge">
                                            HOT
                                        </span>
                                    </div>
                                <?php elseif($imageCount == 3): ?>
                                    <div class="image-container" style="position: relative;">
                                        <div class="row">
                                            <div class="col-8 padding_0px">
                                                <img class="img-two" src="<?php echo e(asset('images')); ?>/<?php echo e($imageNames[0]); ?>">
                                            </div>
                                            <div class="col-4 padding_0px">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <img class="img-three"
                                                            src="<?php echo e(asset('images')); ?>/<?php echo e($imageNames[1]); ?>">
                                                    </div>
                                                    <div class="col-12">
                                                        <img class="img-three"
                                                            src="<?php echo e(asset('images')); ?>/<?php echo e($imageNames[2]); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <span class="price-tag"
                                            style="position: absolute; top: 10px; left: 10px; background: linear-gradient(45deg, #EA4492, #004E9A); color: #fff; padding: 5px 10px; border-radius: 5px; font-weight: bold; font-size: 1.1rem; text-shadow: 2px 2px 3px rgba(0,0,0,0.9);">
                                            <?php echo e(number_format($item->gia_tien, 0, ',', '.')); ?> VNĐ/tháng
                                        </span>
                                        <span class="vip-badge">
                                            HOT
                                        </span>
                                    </div>
                                <?php endif; ?>

                                <div class="card mb-4 shadow-sm">
                                    <div class="card-body">
                                        <p class="card-text line-clamp-2"><?php echo e($item->tieu_de); ?></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <span style="font-weight: bold">Đánh giá chủ nhà:</span>
                                                <span>
                                                    <?php if($item->rate == 1): ?>
                                                        <label style="color: rgb(255, 183, 0)">★☆☆☆☆</label>
                                                    <?php elseif($item->rate == 2): ?>
                                                        <label style="color: rgb(255, 183, 0)">★★☆☆☆</label>
                                                    <?php elseif($item->rate == 3): ?>
                                                        <label style="color: rgb(255, 183, 0)">★★★☆☆</label>
                                                    <?php elseif($item->rate == 4): ?>
                                                        <label style="color: rgb(255, 183, 0)">★★★★☆</label>
                                                    <?php elseif($item->rate == 5): ?>
                                                        <label style="color: rgb(255, 183, 0)">★★★★★</label>
                                                    <?php else: ?>
                                                        <label>Chưa có đánh giá</label>
                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <span style="font-weight: bold">👤: <?php echo e($item->hoTen); ?></span>
                                                <span style="color: blue"> || </span>
                                                <span style="font-weight: bold">Số điện thoại: <?php echo e($item->sdt); ?></span>
                                            </div>
                                            <small class="text-muted">
                                                <span class="icon">📅</span> Ngày Đăng: <?php echo e($item->updated_at); ?>

                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <style>
                        .price-tag {
                            position: absolute;
                            top: 10px;
                            left: 10px;
                            background: linear-gradient(45deg, #EA4492, #004E9A);
                            color: #fff;
                            padding: 5px 10px;
                            border-radius: 5px;
                            font-weight: bold;
                            font-size: 1.1rem;
                            text-shadow: 2px 2px 3px rgba(0, 0, 0, 0.9);
                        }

                        .image-container {
                            position: relative;
                        }
                    </style>
                    <?php if(isset($baiviet)): ?>
                        <?php $__currentLoopData = $baiviet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->user_id == Auth::id()): ?>
                                <a href="<?php echo e(route('baiviet.dkVip', ['id' => $item->id])); ?>" class="btn btn-danger">Đăng kí bài
                                    vip</a>
                            <?php endif; ?>

                            <a class="text-reset text-decoration-none"
                                href="<?php echo e(route('xemchitiet', ['id' => $item->id, 'slug' => Str::slug($item->tieu_de)])); ?>">
                                <?php
                                    $imageNames = explode(',', $item->anh_gioi_thieu);
                                    $imageCount = count($imageNames);
                                ?>

                                <?php if($imageCount == 1): ?>
                                    <div class="image-container" style="position: relative;">
                                        <img class="img-one" src="<?php echo e(asset('images')); ?>/<?php echo e($imageNames[0]); ?>">
                                        <span class="price-tag"
                                            style="
                                    position: absolute; 
                                    top: 10px; 
                                    left: 10px; 
                                    background: linear-gradient(45deg, #EA4492, #004E9A); 
                                    color: #fff; 
                                    padding: 5px 10px; 
                                    border-radius: 5px; 
                                    font-weight: bold;
                                    font-size: 1.1rem;
                                    text-shadow: 2px 2px 3px rgba(0,0,0,0.9);
                                ">
                                            <?php echo e(number_format($item->gia_tien, 0, ',', '.')); ?> VNĐ/tháng
                                        </span>
                                    </div>
                                <?php elseif($imageCount == 2): ?>
                                    <div class="image-container" style="position: relative;">
                                        <div class="row">
                                            <div class="col-6 padding_0px">
                                                <img class="img-two" src="<?php echo e(asset('images')); ?>/<?php echo e($imageNames[0]); ?>">
                                            </div>
                                            <div class="col-6 padding_0px">
                                                <img class="img-two" src="<?php echo e(asset('images')); ?>/<?php echo e($imageNames[1]); ?>">
                                            </div>
                                        </div>
                                        <span class="price-tag"
                                            style="
                                    position: absolute; 
                                    top: 10px; 
                                    left: 10px; 
                                    background: linear-gradient(45deg, #EA4492, #004E9A); 
                                    color: #fff; 
                                    padding: 5px 10px; 
                                    border-radius: 5px; 
                                    font-weight: bold;
                                    font-size: 1.1rem;
                                    text-shadow: 2px 2px 3px rgba(0,0,0,0.9);
                                ">
                                            <?php echo e(number_format($item->gia_tien, 0, ',', '.')); ?> VNĐ/tháng
                                        </span>
                                    </div>
                                <?php elseif($imageCount == 3): ?>
                                    <div class="image-container" style="position: relative;">
                                        <div class="row">
                                            <div class="col-8 padding_0px">
                                                <img class="img-two" src="<?php echo e(asset('images')); ?>/<?php echo e($imageNames[0]); ?>">
                                            </div>
                                            <div class="col-4 padding_0px">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <img class="img-three"
                                                            src="<?php echo e(asset('images')); ?>/<?php echo e($imageNames[1]); ?>">
                                                    </div>
                                                    <div class="col-12">
                                                        <img class="img-three"
                                                            src="<?php echo e(asset('images')); ?>/<?php echo e($imageNames[2]); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <span class="price-tag"
                                            style="
                                    position: absolute; 
                                    top: 10px; 
                                    left: 10px; 
                                    background: linear-gradient(45deg, #EA4492, #004E9A); 
                                    color: #fff; 
                                    padding: 5px 10px; 
                                    border-radius: 5px; 
                                    font-weight: bold;
                                    font-size: 1.1rem;
                                    text-shadow: 2px 2px 3px rgba(0,0,0,0.9);
                                ">
                                            <?php echo e(number_format($item->gia_tien, 0, ',', '.')); ?> VNĐ/tháng
                                        </span>
                                    </div>
                                <?php endif; ?>

                                <div class="card mb-4 shadow-sm">
                                    <div class="card-body">
                                        <p class="card-text line-clamp-2"><?php echo e($item->tieu_de); ?></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <span style="font-weight: bold">Đánh giá chủ nhà:</span>
                                                <span>
                                                    <?php if($item->rate == 1): ?>
                                                        <label style="color: rgb(255, 183, 0)">★☆☆☆☆</label>
                                                    <?php elseif($item->rate == 2): ?>
                                                        <label style="color: rgb(255, 183, 0)">★★☆☆☆</label>
                                                    <?php elseif($item->rate == 3): ?>
                                                        <label style="color: rgb(255, 183, 0)">★★★☆☆</label>
                                                    <?php elseif($item->rate == 4): ?>
                                                        <label style="color: rgb(255, 183, 0)">★★★★☆</label>
                                                    <?php elseif($item->rate == 5): ?>
                                                        <label style="color: rgb(255, 183, 0)">★★★★★</label>
                                                    <?php else: ?>
                                                        <label>Chưa có đánh giá</label>
                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <span style="font-weight: bold">👤: <?php echo e($item->hoTen); ?></span>
                                                <span style="color: blue"> || </span>
                                                <span style="font-weight: bold">Số điện thoại: <?php echo e($item->sdt); ?></span>
                                            </div>
                                            <small class="text-muted">
                                                <span class="icon">📅</span> Ngày Đăng: <?php echo e($item->updated_at); ?>

                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="col-md-4" style="border-radius:8px; border: 3px solid #868686; padding: 15px;">
                    <div class="row">
                        <div class="col-12">
                            <h5
                                style="
                                background: linear-gradient(45deg, #EA4492, #004E9A);
                                -webkit-background-clip: text;
                                -webkit-text-fill-color: transparent;
                                font-weight: 700;
                            ">
                                TOP CHỦ NHÀ ĐƯỢC ĐÁNH GIÁ CAO NHẤT
                            </h5>
                            <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div
                                    style="background: linear-gradient(45deg, rgba(234,68,146,0.2), rgba(0,78,154,0.2)); border-radius:8px; padding: 10px; margin-bottom: 10px;">
                                    <label><?php echo e($item->hoTen); ?>: </label>
                                    <?php if($item->rate == 1): ?>
                                        <label style="color: rgb(255, 183, 0)">★☆☆☆☆</label>
                                    <?php elseif($item->rate == 2): ?>
                                        <label style="color: rgb(255, 183, 0)">★★☆☆☆</label>
                                    <?php elseif($item->rate == 3): ?>
                                        <label style="color: rgb(255, 183, 0)">★★★☆☆</label>
                                    <?php elseif($item->rate == 4): ?>
                                        <label style="color: rgb(255, 183, 0)">★★★★☆</label>
                                    <?php elseif($item->rate == 5): ?>
                                        <label style="color: rgb(255, 183, 0)">★★★★★</label>
                                    <?php else: ?>
                                        <label style="font-weight:bold;">Chưa có đánh giá</label>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <hr style="margin: 20px 0; border-top: 2px dashed #868686; width: 100%;">

                        <div class="col-12">
                            <h5
                                style="
                                background: linear-gradient(45deg, #EA4492, #004E9A);
                                -webkit-background-clip: text;
                                -webkit-text-fill-color: transparent;
                                font-weight: 700;
                            ">
                                BÀI VIẾT ĐỀ XUẤT
                            </h5>
                            <?php if($recommendations->isEmpty()): ?>
                                <p style="color: #fff;">Không có bài viết đề xuất nào.</p>
                            <?php else: ?>
                                <?php $__currentLoopData = $recommendations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $imageNames = explode(',', $value->anh_gioi_thieu);
                                        $firstImage = count($imageNames) > 0 ? trim($imageNames[0]) : null;
                                    ?>
                                    <a href="<?php echo e(route('xemchitiet', ['id' => $value->id, 'slug' => Str::slug($value->tieu_de)])); ?>"
                                        class="d-flex align-items-center mb-3 text-decoration-none"
                                        style="background-color: #3a5560; border-radius: 8px; padding: 10px;">

                                        <?php if($firstImage): ?>
                                            <img src="<?php echo e(asset('images/' . $firstImage)); ?>" alt="Ảnh"
                                                style="width: 60px; height: 60px; object-fit: cover; border-radius: 6px; margin-right: 10px;">
                                        <?php endif; ?>

                                        <div>
                                            <div
                                                style="
                                                color: #fff; 
                                                font-weight: 600; 
                                                font-size: 14px; 
                                                white-space: nowrap; 
                                                overflow: hidden; 
                                                text-overflow: ellipsis; 
                                                max-width: 200px;">
                                                <?php echo e($value->tieu_de); ?>

                                            </div>
                                            <div style="color: #fff; font-size: 13px;">
                                                <?php echo e(number_format($value->gia_tien, 0, ',', '.')); ?> VNĐ/tháng
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>


            </div>

            <div class="pagi">
                <?php echo e($baiviet->links()); ?>

            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function() {
            var selectedPhuongXaId = "<?php echo e($phuong_xa_id ?? ''); ?>";
            var idQuanHuyen = $('#quan_huyen').val();
            $.ajax({
                url: '<?php echo e(route('baiviet.ajax_phuongxa')); ?>' + '/?idquanhuyen=' + idQuanHuyen,
                type: 'GET',
                success: function(data) {
                    console.log(data);
                    $('#phuong_xa').empty();
                    $('#phuong_xa').append(`<option value="0">---Chọn phường/xã---</option>`);
                    $.each(data, function(index, item) {
                        var option = $('<option>', {
                            value: item.id,
                            text: item.name
                        });
                        if (selectedPhuongXaId && selectedPhuongXaId == item.id) {
                            option.prop('selected', true);
                        }
                        $('#phuong_xa').append(option);
                    });
                }
            });

            $('#quan_huyen').on('change', function() {
                var idQuanHuyen = $(this).val();

                $.ajax({
                    url: '<?php echo e(route('baiviet.ajax_phuongxa')); ?>' + '/?idquanhuyen=' +
                        idQuanHuyen,
                    type: 'GET',
                    success: function(data) {
                        console.log(data);
                        $('#phuong_xa').empty();

                        $('#phuong_xa').append(
                            `<option value="0">---Chọn phường/xã---</option>`);
                        $.each(data, function(index, item) {
                            $('#phuong_xa').append($('<option>', {
                                value: item.id,
                                text: item.name
                            }));
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nhatro\resources\views/home.blade.php ENDPATH**/ ?>