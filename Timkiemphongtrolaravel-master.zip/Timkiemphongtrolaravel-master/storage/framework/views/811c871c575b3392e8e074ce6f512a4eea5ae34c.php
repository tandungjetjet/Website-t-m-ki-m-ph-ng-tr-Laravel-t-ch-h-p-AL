

<?php $__env->startSection('content'); ?>
    <div class="container" style="min-height: 100vh">
        <h1>Thống kê nạp tiền</h1>

        <form action="<?php echo e(route('thongke.napTien')); ?>" method="GET" class="row g-3 mb-4">
            <div class="col-auto">
                <label for="from_date" class="form-label">Từ ngày</label>
                <input type="date" name="from_date" id="from_date" class="form-control" value="<?php echo e(request('from_date')); ?>">
            </div>
            <div class="col-auto">
                <label for="to_date" class="form-label">Đến ngày</label>
                <input type="date" name="to_date" id="to_date" class="form-control" value="<?php echo e(request('to_date')); ?>">
            </div>
            <div class="col-auto align-self-end">
                <button type="submit" class="btn btn-primary">Lọc</button>
            </div>
        </form>

        <?php if(isset($tongTienNap)): ?>
            <div class="card my-3">
                <div class="card-body">
                    <h5>Tổng số giao dịch: <?php echo e($tongGiaoDich); ?></h5>
                    <h5>Tổng tiền nạp thành công: <?php echo e(number_format($tongTienNap)); ?> VNĐ</h5>
                </div>
            </div>

            <h4>Biểu đồ tổng tiền theo ngày</h4>
            <div style="max-width: 600px; height: 300px; margin: auto;">
                <canvas id="chartTongTien"></canvas>
            </div>

            <h4 class="mt-5">Thống kê theo ngày</h4>
            <table class="table table-bordered">
                <thead>
                    <tr style="background-color: black; color:white">
                        <th>Ngày</th>
                        <th>Số giao dịch</th>
                        <th>Tổng tiền (VNĐ)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $thongKeTheoNgay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->ngay); ?></td>
                            <td><?php echo e($item->so_giao_dich); ?></td>
                            <td><?php echo e(number_format($item->tong_tien)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <h4 class="mt-5">Thống kê theo user</h4>
            <table class="table table-bordered">
                <thead>
                    <tr style="background-color: black; color:white">
                        <th>Tên</th>
                        <th>Số lượng giao dịch</th>
                        <th>Tổng tiền (VNĐ)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $thongKeTheoUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->sl); ?></td>
                            <td><?php echo e(number_format($item->total_amount)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script>
                const labels = [
                    <?php $__currentLoopData = $thongKeTheoNgay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        '<?php echo e($item->ngay); ?>',
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ];
                const dataTongTien = [
                    <?php $__currentLoopData = $thongKeTheoNgay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($item->tong_tien); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ];

                const ctx = document.getElementById('chartTongTien').getContext('2d');
                const chartTongTien = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Tổng tiền (VNĐ)',
                            data: dataTongTien,
                            backgroundColor: 'rgba(255, 182, 193, 0.5)',
                            borderColor: 'rgba(255, 105, 180, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return value.toLocaleString('en-US');
                                    }
                                }
                            }
                        },
                        responsive: true,
                        maintainAspectRatio: false
                    }
                });
            </script>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nhatro\resources\views/admin/thongke/tien_nap.blade.php ENDPATH**/ ?>