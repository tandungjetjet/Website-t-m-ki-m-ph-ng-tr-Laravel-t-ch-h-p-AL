<footer class="pt-4 pb-4  custom-navbar">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mb-3">
                <h5 class="mb-3">NHÀ TRỌ SINH VIÊN</h5>
                <p class="mb-1"><strong>Điện thoại:</strong>xxxxxxxxxxxxxx</p>
                <p class="mb-1"><strong>Địa chỉ:</strong> xxxxx, Hà Nội</p>
                <p class="mb-1"><strong>Email:</strong> admin@gmail.com</p>
            </div>

            <div class="col-md-6 mb-3">
                <h5 class="mb-3">Bài đăng mới</h5>
                <ul class="list-unstyled">
                    <?php $__currentLoopData = $baiviet_footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('xemchitiet', ['id' => $item->id, 'slug' => Str::slug($item->tieu_de)])); ?>"
                                class="text-white text-decoration-none">
                                <?php echo e(Str::words($item->tieu_de, 7, '...')); ?> -
                                <?php echo e(number_format($item->gia_tien, 0, ',', '.')); ?> VNĐ/tháng
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\nhatro\nhatro\resources\views/layouts/footer.blade.php ENDPATH**/ ?>