<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\baiviet;
use App\Models\comment;
use App\Models\user_view;

class DetailController extends Controller
{
    //
    public function xemChiTiet($id)
    {
        $baiviet = DB::select("SELECT a.*, b.hoTen, b.sdt, b.rate, c.name tinhtp, d.name quanhuyen, e.name phuongxa
        FROM bai_viet a LEFT JOIN `partner` b 
        ON a.user_id = b.user_id LEFT JOIN tinh_thanhpho c ON a.tinh_thanhpho_id = c.id LEFT JOIN quan_huyen d ON a.quan_huyen_id = d.id LEFT JOIN phuong_xa e ON a.phuong_xa_id = e.id
        WHERE a.id = $id ORDER BY a.created_at");
        // dd($baiviet);
        
        if (Auth::user()) {
            user_view::create([
                'user_id'       => auth()->id(),
                'bai_viet_id'   => $id,
                'quan_huyen_id' => $baiviet[0]->quan_huyen_id,
                'dien_tich'     => $baiviet[0]->dien_tich,
                'gia_tien'      => $baiviet[0]->gia_tien,
            ]);
        }

        $comments = comment::orderBY('id', 'DESC')->where('baiviet_id', $baiviet[0]->id)->get();

        $comments = DB::select("SELECT a.*, b.name FROM comment a JOIN users b ON a.user_id = b.id WHERE baiviet_id = $id");
        // dd($comments);

        $user = $baiviet[0]->user_id;
        $sameBaiViet = DB::select("SELECT a.*, b.hoTen, b.sdt, b.rate, c.name tinhtp, d.name quanhuyen, e.name phuongxa FROM bai_viet a 
        LEFT JOIN partner b ON a.user_id = b.user_id 
        LEFT JOIN tinh_thanhpho c ON a.tinh_thanhpho_id = c.id 
        LEFT JOIN quan_huyen d ON a.quan_huyen_id = d.id 
        LEFT JOIN phuong_xa e ON a.phuong_xa_id = e.id 
        WHERE a.user_id = $user AND a.id <> $id 
        ORDER BY a.created_at DESC LIMIT 5");

        return view('client.baiviet_detail', compact('baiviet', 'comments', 'sameBaiViet'));
    }
}
