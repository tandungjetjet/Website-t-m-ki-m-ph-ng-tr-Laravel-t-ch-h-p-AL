<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Models\User;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    protected function authenticated(Request $request, $user)
    {
        if (is_null($user->email_verified_at)) {
            $otp = Str::upper(Str::random(6));
            $user->otp = $otp;
            $user->save();

            Mail::send('sendMail.confirm', ['code' => $otp], function ($message) use ($user) {
                $message->to($user->email, $user->name)
                        ->subject('Xác nhận OTP đăng nhập');
            });

            return redirect()->route('otp.verify')
                             ->with('message', 'Bạn chưa xác thực OTP. Vui lòng kiểm tra email để nhập mã OTP.');
        }
    }
}
