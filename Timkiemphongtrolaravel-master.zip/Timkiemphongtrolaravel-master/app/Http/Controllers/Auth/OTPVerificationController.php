<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OTPVerificationController extends Controller
{
    public function showOTPForm()
    {
        return view('auth.otp'); // view này sẽ được tạo ở bước tiếp theo
    }

    // Xử lý xác thực OTP
    public function verifyOTP(Request $request)
    {
        $request->validate([
            'otp' => 'required|string',
        ]);

        $user = Auth::user();

        if ($user->otp === $request->otp) {
            // Nếu OTP đúng, đánh dấu email đã xác thực (hoặc cột otp_verified)
            $user->email_verified_at = now();
            $user->otp = null; // Xóa OTP sau khi xác thực
            $user->save();

            return redirect()->route('home')->with('success', 'Xác thực thành công.');
        }

        return back()->withErrors(['otp' => 'Mã OTP không chính xác.']);
    }
}
