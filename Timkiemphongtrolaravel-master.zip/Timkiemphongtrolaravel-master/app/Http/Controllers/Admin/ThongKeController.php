<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ThongKeController extends Controller
{
    public function napTien(Request $request)
    {
        if($request->all()){
            $fromDate = $request->input('from_date');
            $toDate   = $request->input('to_date');

            $tongTienNap = DB::table('result_momo')
                ->where('status', 1)
                ->when($request->filled('from_date') && $request->filled('to_date'), function ($query) use ($fromDate, $toDate) {
                    return $query->whereBetween(DB::raw('DATE(created_at)'), [$fromDate, $toDate]);
                })
                ->sum('amount');

            $tongGiaoDich = DB::table('result_momo')
                ->where('status', 1)
                ->when($request->filled('from_date') && $request->filled('to_date'), function ($query) use ($fromDate, $toDate) {
                    return $query->whereBetween(DB::raw('DATE(created_at)'), [$fromDate, $toDate]);
                })
                ->count();

            $thongKeTheoNgay = DB::table('result_momo')
                ->select(
                    DB::raw('DATE(created_at) as ngay'),
                    DB::raw('COUNT(*) as so_giao_dich'),
                    DB::raw('SUM(amount) as tong_tien')
                )
                ->where('status', '1')
                ->when($request->filled('from_date') && $request->filled('to_date'), function ($query) use ($fromDate, $toDate) {
                    return $query->whereBetween(DB::raw('DATE(created_at)'), [$fromDate, $toDate]);
                })
                ->groupBy(DB::raw('DATE(created_at)'))
                ->orderByDesc('ngay')
                ->get();

            //     dd("SELECT SUM(a.amount) total_amount, COUNT(1) sl, b.`name` FROM `result_momo` a LEFT JOIN users b ON a.user_id = b.id
            // WHERE a.status = 1 AND DATE(a.created_at) BETWEEN '$fromDate' AND '$toDate' GROUP BY a.user_id");
            $thongKeTheoUser = DB::select("SELECT SUM(result_momo.amount) total_amount, COUNT(1) sl, users.`name` 
            FROM `result_momo`LEFT JOIN users ON result_momo.user_id = users.id
            WHERE result_momo.status = 1 AND DATE(result_momo.created_at) BETWEEN '$fromDate' AND '$toDate' GROUP BY result_momo.user_id, users.`name`");


            return view('admin.thongke.tien_nap', ['tongTienNap'=> $tongTienNap,'tongGiaoDich'=> $tongGiaoDich,'thongKeTheoNgay'=> $thongKeTheoNgay,
           'thongKeTheoUser' => $thongKeTheoUser ]);
        }
        return view('admin.thongke.tien_nap');
    }
}
