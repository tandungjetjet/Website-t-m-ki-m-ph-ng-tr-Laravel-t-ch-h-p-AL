<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\baiviet;
use Spatie\Permission\Models\Permission;
use App\Models\partner;
use App\Models\result_momo;
use App\Models\comment;
use Illuminate\Support\Str;
use App\Models\User;
use Carbon\Carbon;
use App\Models\user_view;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $req)
    {
        
        if (!Auth::user()) {
            $oneWeekAgo = Carbon::now()->subWeek();
            $recommendations = DB::table('bai_viet')
                ->leftJoin('user_views', 'bai_viet.id', '=', 'user_views.bai_viet_id')
                ->where('user_views.created_at', '>=', $oneWeekAgo)
                ->select('bai_viet.*', DB::raw('COUNT(user_views.id) as view_count'))
                ->groupBy('bai_viet.id')
                ->orderBy('view_count', 'desc')
                ->limit(10)
                ->get();
        } else {
            $user_id = Auth::user()->id;

            $lastView = user_view::where('user_id', auth()->id())
                ->where('created_at', '>=', Carbon::now()->subDays(10))
                ->orderBy('created_at', 'desc')
                ->first();

            if (!$lastView) {
                $oneWeekAgo = Carbon::now()->subWeek();
                $recommendations = DB::table('bai_viet')
                    ->leftJoin('user_views', 'bai_viet.id', '=', 'user_views.bai_viet_id')
                    ->where('user_views.created_at', '>=', $oneWeekAgo)
                    ->select('bai_viet.*', DB::raw('COUNT(user_views.id) as view_count'))
                    ->groupBy('bai_viet.id')
                    ->orderBy('view_count', 'desc')
                    ->limit(10)
                    ->get();
            } else {
                $userQuanHuyen = $lastView->quan_huyen_id;
                $userDienTich  = $lastView->dien_tich;
                $userGiaTien   = $lastView->gia_tien;
    
                // Tính khoảng ±10% của diện tích
                $minDienTich = $userDienTich * 0.9;
                $maxDienTich = $userDienTich * 1.1;
    
                $recommendations = DB::table('bai_viet')
                    ->where('quan_huyen_id', $userQuanHuyen)
                    ->where('gia_tien', '<', $userGiaTien)
                    ->where(function ($query) use ($minDienTich, $maxDienTich, $userDienTich) {
                        $query->whereBetween('dien_tich', [$minDienTich, $maxDienTich])
                                ->orWhere('dien_tich', '>', $userDienTich);
                    })
                    ->orderByRaw("CASE WHEN dien_tich BETWEEN $minDienTich AND $maxDienTich THEN 0 ELSE 1 END, gia_tien ASC")
                    ->limit(10)
                    ->get();
    
                if ($recommendations->isEmpty()) {
                    $oneWeekAgo = Carbon::now()->subWeek();
                    $recommendations = DB::table('bai_viet')
                        ->leftJoin('user_views', 'bai_viet.id', '=', 'user_views.bai_viet_id')
                        ->where('user_views.created_at', '>=', $oneWeekAgo)
                        ->select('bai_viet.*', DB::raw('COUNT(user_views.id) as view_count'))
                        ->groupBy('bai_viet.id')
                        ->orderBy('view_count', 'desc')
                        ->limit(10)
                        ->get();
                }
            }
        }
        $partner = DB::select("SELECT hoTen, rate FROM `partner` WHERE `type` = 1 ORDER BY rate DESC LIMIT 10");

        if ($req->hasAny(['type', 'gia_tien', 'dien_tich', 'quan_huyen_id', 'phuong_xa_id'])) {

            $type = $req->input('type');
            $gia_tien = $req->input('gia_tien');
            $dien_tich = $req->input('dien_tich');
            $quan_huyen_id = $req->input('quan_huyen_id');
            $phuong_xa_id = $req->input('phuong_xa_id');

            $sql_baiviet = BaiViet::leftJoin('partner', 'bai_viet.user_id', '=', 'partner.user_id')
                ->orderBy('bai_viet.created_at')
                ->select('bai_viet.*', 'partner.hoTen', 'partner.sdt', 'partner.rate');

            if ($type != null) {
                $sql_baiviet = $sql_baiviet->where('bai_viet.type', $type);
            }
            if ($dien_tich != null) {
                if ($dien_tich == 'under20') {
                    $sql_baiviet = $sql_baiviet->where('bai_viet.dien_tich', '<', 20);
                } elseif ($dien_tich == '20-50') {
                    $sql_baiviet = $sql_baiviet->whereBetween('bai_viet.dien_tich', [20, 50]);
                } elseif ($dien_tich == '50-100') {
                    $sql_baiviet = $sql_baiviet->whereBetween('bai_viet.dien_tich', [50, 100]);
                } elseif ($dien_tich == 'over100') {
                    $sql_baiviet = $sql_baiviet->where('bai_viet.dien_tich', '>', 100);
                }
            }
            if ($gia_tien != null) {
                if ($gia_tien == 'under3000') {
                    $sql_baiviet = $sql_baiviet->where('bai_viet.gia_tien', '<', 3000000);
                } elseif ($gia_tien == '3000-5000') {
                    $sql_baiviet = $sql_baiviet->whereBetween('bai_viet.gia_tien', [3000000, 5000000]);
                } elseif ($gia_tien == 'over5000') {
                    $sql_baiviet = $sql_baiviet->where('bai_viet.gia_tien', '>', 5000000);
                }
            }
            if ($quan_huyen_id != 0) {
                $sql_baiviet = $sql_baiviet->where('bai_viet.quan_huyen_id', $quan_huyen_id);
            }
            if ($phuong_xa_id != 0) {
                $sql_baiviet = $sql_baiviet->where('bai_viet.phuong_xa_id', $phuong_xa_id);
            }
            $baiviet = $sql_baiviet->paginate(5);
            return view('home', compact('baiviet', 'quan_huyen_id', 'phuong_xa_id', 'partner','recommendations'));
        }

        $currentDate = now();
        $baivietvip =
            DB::table('bai_viet_vip AS a')
            ->select('b.*', 'c.hoTen', 'c.sdt', 'c.rate')
            ->leftJoin('bai_viet AS b', 'a.bai_viet_id', '=', 'b.id')
            ->leftJoin('partner AS c', 'b.user_id', '=', 'c.user_id')
            ->whereDate('time', $currentDate)
            ->get();

        $baiviet = BaiViet::leftJoin('partner', 'bai_viet.user_id', '=', 'partner.user_id')
            ->orderBy('bai_viet.created_at')
            ->select('bai_viet.*', 'partner.hoTen', 'partner.sdt', 'partner.rate')
            ->paginate(5);

        return view('home', compact('baiviet', 'baivietvip', 'partner', 'recommendations'));
    }

    public function viewQuanHuyen(Request $req, $id){
        $baiviet = BaiViet::leftJoin('partner', 'bai_viet.user_id', '=', 'partner.user_id')
        ->orderBy('bai_viet.created_at')
        ->select('bai_viet.*', 'partner.hoTen', 'partner.sdt', 'partner.rate')
        ->where('bai_viet.quan_huyen_id', $id)
        ->paginate(5);

        $quanHuyen = DB::select("SELECT * FROM quan_huyen WHERE id = $id");
        $partner = DB::select("SELECT hoTen, rate FROM `partner` WHERE `type` = 1 ORDER BY rate DESC");

        return view('client.view_quan_huyen', compact('baiviet','partner','quanHuyen'));
    }

    public function storecomment(Request $request, $id)
    {
        $baiviet_id = $id;
        $baiviet = baiviet::find($id);
        $comment = new comment();
        $comment->baiviet_id = $baiviet_id;
        $comment->user_id = Auth::user()->id;
        $comment->noi_dung = $request->noi_dung;
        $comment->save();
        return redirect("client/xem-chi-tiet/$id/" . Str::slug($baiviet->tieu_de));
    }

    public function redirectMomo(Request $request){
        if ($request->hasAny(['resultCode','orderId','requestId'])) {
            $amount = $request->input('amount');
            $orderId = $request->input('orderId');
            $requestId = $request->input('requestId');
            $result_momo = result_momo::where('orderId', $orderId)->where('requestId', $requestId)->first();

            // dd($result_momo);
            if ($result_momo->status == 0) {
                $user = Auth::user();
                $user_id = $user->id;

                $partner = partner::where('user_id', $user_id)->first();
                if($partner->money == 0){
                    $old_money = 0;
                }
                $old_money = $partner->money;
                $result_momo->update(['status' => 1]);
                $partner->update(['money' => ($old_money + $amount)]);
            }
            return redirect()->route('home');
        }
    }
}
