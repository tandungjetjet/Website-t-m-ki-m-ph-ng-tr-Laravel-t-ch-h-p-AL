<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;
use App\Models\tinh_thanhpho;
use App\Models\quan_huyen;
use App\Models\phuong_xa;
use App\Models\BaiViet;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Paginator::useBootstrap();

        view()->composer("*", function ($view) {
            $moneyPartner = 0;
            if(Auth::user()){
                $user_id = Auth::user()->id;
                $queryPartner = DB::select("SELECT `money` FROM `partner` WHERE user_id = $user_id");
                if($queryPartner != []){
                    $moneyPartner = $queryPartner[0]->money;
                }
            }

            $tinh_thanhpho = tinh_thanhpho::all();
            $quan_huyen = quan_huyen::all();
            $phuong_xa = phuong_xa::all();
            $view->with(compact('tinh_thanhpho', 'quan_huyen', 'phuong_xa','moneyPartner'));
        });
    }
}
