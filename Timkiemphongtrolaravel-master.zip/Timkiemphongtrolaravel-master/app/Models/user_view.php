<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class user_view extends Model
{
    use HasFactory;

    protected $table = 'user_views';

    protected $fillable = [
        'id',
        'user_id',
        'bai_viet_id',
        'quan_huyen_id',
        'dien_tich',
        'gia_tien',
        'created_at',
        'updated_at',
    ];
}
